package com.example.proyectocalculadora;

public class Calculadora  {
        public double sumar(double num1, double num2) {
            return num1 + num2;
        }

        public double restar(double num1, double num2) {
            return num1 - num2;
        }

        public double multiplicar(double num1, double num2) {
            return num1 * num2;
        }

        public double dividir(double num1, double num2) {
            if (num2 != 0) {
                return num1 / num2;
            } else {
                return Double.NaN; // Manejo de división por cero
            }
        }

        public double potencia(double base, int exponente) {
            if (exponente == 0) {
                return 1;
            } else if (exponente < 0) {
                return 1 / (base * potencia(base, -exponente - 1));
            } else {
                return base * potencia(base, exponente - 1);
            }
        }
    }

