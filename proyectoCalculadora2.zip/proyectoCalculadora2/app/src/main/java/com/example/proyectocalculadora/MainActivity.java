package com.example.proyectocalculadora;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView resultado;
    private String input = "";
    private double num1 = 0, num2 = 0;
    private char operador = ' ';
    private Calculadora calculadora = new Calculadora();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultado = findViewById(R.id.resultado);
    }

    public void botonNumeroClick(View view) {
        Button boton = (Button) view;
        String textoBoton = boton.getText().toString();

        // Evitar que se ingresen múltiples ceros al principio
        if (input.equals("0")) {
            input = textoBoton;
        } else {
            input += textoBoton;
        }

        resultado.setText(input);
    }

    public void botonOperadorClick(View view) {
        Button boton = (Button) view;
        if (!input.isEmpty()) {
            num1 = Double.parseDouble(input);
            operador = boton.getText().toString().charAt(0);

            // Mostrar num1, operador y un espacio en el TextView
            resultado.setText(num1 + " " + operador + " ");

            // Reiniciar input para capturar num2
            input = "";
        }
    }

    public void puntoDecimalClick(View view) {
        if (!input.contains(".")) {
            input += ".";
            resultado.setText(input);
        }
    }

    public void botonIgualClick(View view) {
        if (!input.isEmpty()) {
            num2 = Double.parseDouble(input);
            double resultadoCalculado = 0.0; // Inicializa el resultado a cero

            switch (operador) {
                case '+':
                    resultadoCalculado = calculadora.sumar(num1, num2);
                    break;
                case '-':
                    resultadoCalculado = calculadora.restar (num1, num2);
                    break;
                case '×':
                    resultadoCalculado = calculadora.multiplicar(num1, num2);
                    break;
                case '÷':
                    resultadoCalculado = calculadora.dividir(num1, num2);
                    break;
                case '^':
                    resultadoCalculado = calculadora.potencia(num1, (int) num2);
                    break;
                default:
                    // Manejo de operador desconocido (puede ser un error en tu lógica)
                    resultadoCalculado = Double.NaN;
            }

            input = String.valueOf(resultadoCalculado);

            if (Double.isNaN(resultadoCalculado)) {
                resultado.setText("ERROR");
            } else {
                resultado.setText(input);
            }
        }
    }

    public void botonResetearClick(View view) {
        num1 = 0;
        num2 = 0;
        operador = ' ';
        input = "";
        resultado.setText("0");
    }
}
